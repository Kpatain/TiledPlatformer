# TiledPlatformer

 https://kpatain.github.io/TiledPlatformer/
 
http://localhost/Tiledplatformer/


QUE FAIS JE ICI

 
 TO DO
 
   - Le trou noir
   - la tileset à continuée
   - herbe
   - asteroide
   - fin?
   
   
 A SAVOIR
 - bon normalement le gros bug de collides est resolu !
 - l'ambiance commence a s'installer mais je ferai ma musique en dernier
 -l'emplacement du tuto n'est pas finale
 
 MON PLANNING
   - en 1er c'est faire l'antagoniste (trou noir)
   - l'équilibré
   - finir le ld
   - finir le graphisme
   - equilibrage
   - test
   - equilibrage
   - musique
   - son
   - et bim
